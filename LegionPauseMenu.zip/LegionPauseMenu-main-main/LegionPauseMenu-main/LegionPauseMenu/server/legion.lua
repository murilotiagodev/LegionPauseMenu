
RegisterServerEvent('pausemenu:quit')
AddEventHandler('pausemenu:quit', function()
DropPlayer(source,"Pause menu quit !")

end)

print("Legion PAUSE MENU")
