REDM PAUSE MENU  FREE

Working on All Cores

DISCORD LEGION STORE https://discord.gg/uQudG2U734

GitHub [https://github.com/](https://github.com/MurilotiagoTI)

Download [https://github.com/](https://github.com/MurilotiagoTI/LegionPauseMenu-main)

Credit billzoygkos

Original Post GTA 5 FIVEM RP
https://forum.cfx.re/t/release-pause-menu/4919651

Converted for Redm By legion

How to Instal 
1) Download 
2) Drag and Drop to your Resources 
3) Ensure to your server.cfg ensure LegionPauseMenu


For support join my Discord server
